function [EeeT_est, g_est, rho2_est] = EIVD(x)
%% This function is a modified version of SNRest to estimate TC-like results
% Version 3 (updated on 23 Mar 2024)
% Update details: same results but with more detailed steps
%
% INPUT
%   x = covariance matrix of x (p x p)
%
% OUTPUT 
%   EeeT_est = estimated error covariance matrix (p x p)
%   theta_est = estimated theta (p x 1, = a*sqrt(Ey2))
%   rho2_est = estimated squared data-truth correlation (p x 1)
%
% REFERENCE
% For more details, see:
%
% Kim, S., Sharma, A., Liu, Y. Y., & Young, S. I. (2021). 
% Rethinking Satellite Data Merging: From Averaging to SNR Optimization.
% IEEE Trans Geosci Remote Sens
%
% If you use the methods presented in the paper and/or this example, 
% please cite this paper where appropriate.
%
% three input variables - note the sequence

p = size(x,2); % data matrix nxp
noLag = 1;
xLag = x;xLag(1:end-noLag,:) = x(noLag+1:end,:);
covx = cov(x);

varLag = nan(p,1);
for i = 1:p
    temp = cov(x(1:end-noLag,i),xLag(noLag+1:end,i));
    varLag(i,1) = temp(1,1);
end
covxLag = diag(varLag);
Df = covx - covxLag;

%% Estimation
% Parameters
beta = 0.5*min(diag(Df)); % Calculate initial value for beta parameter (tuning parameter for initializing a), which is set to 0.5*min(diag(C))
lamda = 0.01; % Set learning rate to 0.01
iters = 2000; % Set number of iterations for gradient descent to 2000

% Initialization
[V,D] = eig(Df-beta*eye(p)); % Compute eigenvectors V and eigenvalues D of the matrix Df-beta*I, where I is identity matrix of size P.
g_est = V(:,end)*sqrt(D(end)); % Initialize a_est to the eigenvector corresponding to the largest eigenvalue of C-beta*I, scaled by the square root of that eigenvalue.
g_est = g_est .* sign(g_est); % Make all entries of a_est positive by taking the element-wise sign of a_est
g_init = g_est; % Store initial value of a_est
lamda = lamda/norm(g_init); % normalizing lamda considering the norm of a_init
eta = ones(p,1);

% Iterations
for i = 1:iters % Loop through the number of iterations specified
    grad = ((eta*eta'-eye(p)).*sign(g_est*g_est'-Df))*g_est;
    
    % Update a_est using gradient descent
    g_est = g_est - lamda*grad; 

    % Projecting non-negativity constraint on the updated a_est values
    g_est = g_est - sign(g_est) .*  sqrt(max(diag(g_est*g_est'-Df),0));    

end

% Calculate EeeT_est and rho2_est using theta_est
EeeT_est = Df - g_est*g_est';
rho2_est = diag((g_est*g_est')./covx);

end